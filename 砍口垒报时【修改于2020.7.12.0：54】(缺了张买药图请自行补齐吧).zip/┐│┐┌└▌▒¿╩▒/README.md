# 砍口垒报时

## Hoshino版本

V1，V2均可

---
## 文件说明

### record文件夹

- 内容：内含三个包含语音的文件夹
- 放置位置
  
  将三个文件夹里的音频放在CoolQ/data/record文件夹内

  （注：三个文件夹只是下载的时候区分音频用的，只要将里面的音频文件放到上面要求的位置）

### `config.json`

- 作用

  用于存放时报“文本”

- 放置位置
  
  放在 ***/Hoshino/modules/hourcall 路径下覆盖掉原有文件（如果有原文件的话）

  - 注：
    
    - 如果是从V1手动更新到V2的话，原本该路径下的`config.json`文件是保留下来的，不过已经没有用了（因为V2的时报文本放在了***/Hoshino/config/hourcall.py中）；  

    - 如果是最近重新git拉取的V2应该是没有`config.json`文件的

### `hourcall.py`

- 作用

  用于从 modules/hourcall 目录下的`config.json`的 HOUR_CALLS 中挑出一组时报，（每日更换，一日之内保持相同）

  并在每个整点从已挑选出的时报组中顺序播报3条时报

- 放置位置
  
  放在 ***/Hoshino/modules/hourcall 路径下覆盖掉原有文件

- 注意事项 
  
  Hoshino V2 在该路径下的`hourcall.py`与这里的`hourcall.py`是不同的，V2中的该文件已放在该文件夹中：`V2hourcall模块里的hourcall.py`

### `V2hourcall模块里的hourcall.py`

- 作用

  存放了Hoshino V2 在  ***/Hoshino/modules/hourcall 文件夹中的`hourcall.py`文件

- 为什么会有这个文件夹

  因为用同样的方法V1和V2都能正常使用该时报，所以不想分V1和V2来写了（摸了）

  不替换V2在这里的`hourcall.py`的话需要将`config.json`中的代码对应改到***/modules/config/hourcall.py文件中

---

## 使用方法

   按照文件说明中的说明对应放置好文件之后重启Hoshino即可

   （在Hoshino运行窗口中按Ctrl+C中断程序并重新输入`python run.py`回车运行）

---