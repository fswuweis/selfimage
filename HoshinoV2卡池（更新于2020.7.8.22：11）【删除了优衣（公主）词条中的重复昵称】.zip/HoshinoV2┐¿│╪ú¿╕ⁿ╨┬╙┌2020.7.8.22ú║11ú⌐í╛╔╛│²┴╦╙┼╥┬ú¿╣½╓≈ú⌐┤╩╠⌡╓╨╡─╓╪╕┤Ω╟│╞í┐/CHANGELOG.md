# 更新日志

## 2020

### 7-08-22:08

- 修改了`_pcr_data.py`第154行1802的优衣（公主）词条，删除了重复的优衣（公主）字样

### 7-08-10:21

- 修改了readme.txt中unit文件夹中文件存放的相对路径，原本是**/hoshino/modules/img/priconne/unit（img前面应当是RES_DIR）  ；
- 修改了readme文件的格式，改用markdown格式；

### 7-06-11:20

- 修改config卡池，补上了BL卡池缺少的真步，真琴，咲恋3张卡；
