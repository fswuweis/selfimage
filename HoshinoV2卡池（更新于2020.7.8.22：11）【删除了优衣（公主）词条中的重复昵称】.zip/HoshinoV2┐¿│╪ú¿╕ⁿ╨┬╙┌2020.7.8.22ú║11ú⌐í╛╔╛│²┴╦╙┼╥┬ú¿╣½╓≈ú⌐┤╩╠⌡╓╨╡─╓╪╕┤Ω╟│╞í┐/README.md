﻿## Hoshino版本

- V2

***
## 卡池

- 国服伊利亚；日服水流夏；台服优妮

***
## 文件说明

### unit文件夹

- 里面是人物头像，放到RES_DIR/img/priconne/unit目录下（如果提示重复，那说明这些图片你已经有了）
- RES_DIR是资源库文件夹，在你的**/hoshino/config/`__bot__.py`的第32行中已设置

### `_pcr_data.py`

- 人物昵称表，放到**/hoshino/modules/priconne目录下覆盖掉原来的文件

### config.json

- 卡池设置，放到**/hoshino/modules/priconne/gacha目录下覆盖掉原来的文件

***


